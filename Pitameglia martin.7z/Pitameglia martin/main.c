#include <stdio.h>
#include <stdlib.h>
#define H 5
#define C 51
#define FIAT 1
#define PEUGEOT 2
#define FORD 3
#define OTRO 4
#include "Funsion.h"

int main()
{
    int i;
    int profesor;
    int quit = 1;
    int estacionamiento[H] = {0};//profesor estacionado 0 vacio
    Sauto aut0[H];
    HarcodearSArray(H, aut0);
    /*while()
    {
    }*/
    printf("ingrese el profesor que quiere ingresar a la cochera");
    scanf("%d", &profesor);
    i = valProfesor(H, profesor, aut0);
    while(i < 0)
    {
        printf("ingreso mal el profesor, por favor ingrese de nuevo");
        scanf("%d", &profesor);
    }


    estacionar(estacionamiento, aut0[i]);
    //aut0[2]=cargarAuto(aut0[2]);
    for(i = 0; i < H; i++)
    {
        MostrarS(aut0[i]);
    }

    return 0;
}
