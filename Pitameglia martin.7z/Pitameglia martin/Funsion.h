#define C 51
typedef struct
{
    char patente[C];
    char modelo[C];
    int marca;//(1.fiat 2.peugeot 3.ford 4.otros)
    int profesor;

}Sauto;


Sauto bajaAuto();
int estacionar(int[], Sauto);


/*SPersona HarcodearS(char[], char[], char[], int, int, float, float);
/** \brief harcodea a una estructura de tipo SPersona con argumentos
 *
 * \param vector(20) de caracteres que representa el nombre
 * \param vector(20) de caracteres que representa el telefono
 * \param vector(40) de caracteres que representa la nacionalidad
 * \param entero que representa la edad
 * \param entero que representa el DNI
 * \param flotante que representa la altura
 * \param flotante que representa el peso
 * \return
 *
 */

 Sauto cargarAuto(Sauto);

int valProfesor(int, int, Sauto[]);

char cargarCaracter(int , char[]);


void HarcodearSArray(int ,Sauto[]);



void MostrarS(Sauto);
/** \brief muestra toda la informacion de tipo SPersona
 *
 * \param un dato de tipo SPersona
 *
 */
//char cargarCaracter(int, char[tam]):
