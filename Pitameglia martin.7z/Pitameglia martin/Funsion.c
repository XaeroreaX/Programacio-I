#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define H 5
#define C 51
#define FIAT 1
#define PEUGEOT 2
#define FORD 3
#define OTRO 4
#include "Funsion.h"

/*SPersona HarcodearS(char nombre[NT], char telefono[NT], char nacionalidad[N], int edad, int dni, float altura, float peso)
{



    strcpy(persona.nombre, nombre);
    strcpy(persona.telefono, telefono);
    strcpy(persona.nacionalidad, nacionalidad);
    persona.edad = edad;
    persona.dni = dni;
    persona.altura = altura;
    persona.peso = peso;

    return persona;
}*/

/**-----------------------------------------------------------------------------------------------------------------------*/
void HarcodearSArray(int tam,Sauto aut0[H])
{
    int i = 0;
    char patente[H][C] = {"jgh-456","pit-785","Pae-159","yTe-762","poe-789"};
    char modelo[H][C] = {"fiat 600","pepito","gigabite","german","nahue"};
    int marca[H] = {FORD, PEUGEOT, OTRO, FORD, FIAT};//(1.fiat 2.peugeot 3.ford 4.otros)
    int profesor[H] = {1001, 1002, 1003, 1004, 1005};

    for(i = 0; i < tam; i++)
    {
        strcpy(aut0[i].patente, patente[i]);
        strcpy(aut0[i].modelo, modelo[i]);
        aut0[i].marca = marca[i];
        aut0[i].profesor = profesor[i];

    }

}

/**-----------------------------------------------------------------------------------------------------------------------*/


Sauto cargarAuto(Sauto aut0)
{



        printf("\ningrese la patente del auto");
        aut0.patente[C] = cargarCaracter(C, aut0.patente);
        printf("\ningrese el modelo del auto");
        aut0.modelo[C] = cargarCaracter(C, aut0.modelo);
        printf("\ningrese la marca:\n1. FIAT\n2.PEUGEOT\n3. FORD\n4. OTRO");
        scanf("%d", &aut0.marca);
        printf("\ningrese el numero del profesor");
        scanf("%d", &aut0.profesor);
        while(aut0.profesor < 1000)
        {
            printf("\ningreso mal el numero del profesor, porfavor ingrese de nuevo");
            scanf("%d", &aut0.profesor);
        }
        return aut0;
}


/**-----------------------------------------------------------------------------------------------------------------------*/

char cargarCaracter(int tam, char caracteres[tam])
{
    char buffer[1024];

    gets(buffer);
    while(strlen(buffer) > tam)
    {
        printf("ingreso mal la cadena de caracteres, ingrese de nuevo");
        gets(buffer);
    }
    strcpy(caracteres, buffer);

    return caracteres;
}

/**-----------------------------------------------------------------------------------------------------------------------*/

void mostrarAEstacionados
void MostrarS(Sauto aut0)
{
    if(aut0.profesor == 0)
    {
        printf("\nno hay datos\n");
    }
    else
    {
        printf("\npatente:%s----modelo:%s----profesor:%d", aut0.patente, aut0.modelo, aut0.profesor);
        printf("-------------marca:");
        switch(aut0.marca)
        {
            case FIAT:
                printf("FIAT\n");
                break;
            case PEUGEOT:
                printf("PEUGEOT\n");
                break;
            case FORD:
                printf("FORD\n");
                break;
            case OTRO:
                printf("OTRO\n");
                break;

        }
    }

}
int valProfesor(int tam,int profesor, Sauto aut0[tam])
{
    int i;
    for(i = 0; aut0[i].profesor != profesor && i < tam; i++);
    if(i < tam)
    {
        return i;
    }
    else
    {
        return -1;
    }
}
int estacionar(int estacion[H], Sauto aut0)
{
    int i;
    for(i = 0;estacion[i] != 0 && i < H; i++);
    if(i < H)
    {
        estacion[i] = aut0.profesor;
        printf("ingreso en el lugar %d", i + 1);
    }
    else
    {
        printf("no se encontro lugar de estacionamiento");
    }
}



Sauto bajaAuto()
{
    Sauto aut0;
    strcpy(aut0.patente, "");
    strcpy(aut0.modelo, "");
    aut0.marca = 0;
    aut0.profesor = 0;

    return aut0;
}
